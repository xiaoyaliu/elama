<template>
    <div>
       ratings
    </div>
</template>

<script type="text/ecmascript-6">

    export default {
        name: 'app',
        components: {}
    }
</script>
